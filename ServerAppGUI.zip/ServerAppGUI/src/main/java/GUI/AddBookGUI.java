/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Domain.AddBook;
import Domain.AddLearner;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author Zandr
 */
public class AddBookGUI extends JFrame implements ActionListener{
    private JPanel panelNorth, panelLeft, panelCenter, panelSouth;
    private JLabel lblImage, lblHeader, lblBookTitle, lblBookShelf, lblBookISBN, lblAuthor, lblBookCategory, lblAvailableForLoan;
            //lblDateOfPurchase;// lblPostalCode, lblCountry, lblPhone, lblFax;
    private JTextField txtBookTitle, txtBookShelf, txtBookISBN, txtBookAuthor, txtBookCategory, txtAvailableForLoan;
            //txtDateOfPurchase; // txtPostalCode, txtCountry, txtPhone, txtFax;
    private JButton btnBackToMain, btnUpdate, btnReset, btnDelete, btnExit;

    private Font font, fontLabels;

    public AddBookGUI() {
        super("Book");
        panelNorth = new JPanel();
        panelLeft = new JPanel();
        panelCenter = new JPanel();
        panelSouth = new JPanel();

        lblImage = new JLabel(new ImageIcon("user.png"));
        lblHeader = new JLabel("Fill New Book Information");

        lblBookTitle = new JLabel("Customer Title:            ");
        txtBookTitle = new JTextField();
        lblBookShelf = new JLabel("Book Shelf:            ");
        txtBookShelf = new JTextField();
        lblBookISBN = new JLabel("Book ISBN:            ");
        txtBookISBN = new JTextField();
        lblAuthor = new JLabel("Book Author:            ");
        txtBookAuthor = new JTextField();
        lblBookCategory = new JLabel("Book Category:            ");
        txtBookCategory = new JTextField();
        lblAvailableForLoan = new JLabel("Available For Loan:            ");
        txtAvailableForLoan = new JTextField();
        //lblDateOfPurchase = new JLabel("Region:            ");
        //txtRegion = new JTextField();
        //lblPostalCode = new JLabel("Postal Code:            ");
        //txtPostalCode = new JTextField();
        //lblCountry = new JLabel("Country:            ");
        //txtCountry = new JTextField();
        //lblPhone = new JLabel("Phone:            ");
        //txtPhone = new JTextField();
        //lblFax = new JLabel("Fax:            ");
        //txtFax = new JTextField();
        btnBackToMain = new JButton("Back To Main Menu");
        btnUpdate = new JButton("Update");
        btnReset = new JButton("Reset");
        btnDelete = new JButton("Delete");
        btnExit = new JButton("Exit");

        font = new Font("Arial", Font.PLAIN, 26);
        fontLabels = new Font("Arial", Font.PLAIN, 22);
    }

    public void setFrame() {

        panelNorth.setLayout(new FlowLayout());
        panelLeft.setLayout(new GridLayout(7, 1));
        panelCenter.setLayout(new GridLayout(7, 1));
        panelSouth.setLayout(new GridLayout(1, 5));

        panelNorth.add(lblImage);
        panelNorth.add(lblHeader);
        lblHeader.setFont(font);
        lblHeader.setForeground(Color.yellow);
        panelNorth.setBackground(Color.BLUE);

        panelLeft.add(lblBookTitle);
        lblBookTitle.setFont(fontLabels);
        panelCenter.add(txtBookTitle);

        panelLeft.add(lblBookShelf);
        lblBookShelf.setFont(fontLabels);
        panelCenter.add(txtBookShelf);

        panelLeft.add(lblBookISBN);
        lblBookISBN.setFont(fontLabels);
        panelCenter.add(txtBookISBN);

        panelLeft.add(lblAuthor);
        lblAuthor.setFont(fontLabels);
        panelCenter.add(txtBookAuthor);

        panelLeft.add(lblBookCategory);
        lblBookCategory.setFont(fontLabels);
        panelCenter.add(txtBookCategory);

        panelLeft.add(lblAvailableForLoan);
        lblAvailableForLoan.setFont(fontLabels);
        panelCenter.add(txtAvailableForLoan);

//        panelLeft.add(lblDateOfPurchase);
  //      lblDateOfPurchase.setFont(fontLabels);
       // panelCenter.add(txtDateOfPurchase);

        /*panelLeft.add(lblPostalCode);
        lblPostalCode.setFont(fontLabels);
        panelCenter.add(txtPostalCode);

        panelLeft.add(lblCountry);
        lblCountry.setFont(fontLabels);
        panelCenter.add(txtCountry);

        panelLeft.add(lblPhone);
        lblPhone.setFont(fontLabels);
        panelCenter.add(txtPhone);

        panelLeft.add(lblFax);
        lblFax.setFont(fontLabels);
        panelCenter.add(txtFax);*/
        btnBackToMain.setFont(font);
        btnUpdate.setFont(font);
        btnReset.setFont(font);
        btnDelete.setFont(font);
        btnExit.setFont(font);
        panelSouth.add(btnBackToMain);
        panelSouth.add(btnUpdate);
        panelSouth.add(btnReset);
        panelSouth.add(btnDelete);
        panelSouth.add(btnExit);

        this.add(panelNorth, BorderLayout.NORTH);
        this.add(panelLeft, BorderLayout.WEST);
        this.add(panelCenter, BorderLayout.CENTER);
        this.add(panelSouth, BorderLayout.SOUTH);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        btnBackToMain.addActionListener((ActionListener) this);
        btnUpdate.addActionListener((ActionListener) this);
        btnReset.addActionListener((ActionListener) this);
        btnDelete.addActionListener((ActionListener) this);
        btnExit.addActionListener((ActionListener) this);

        this.setSize(600, 400);
        //this.setJMenuBar(menuBar);
        this.pack();
        this.setVisible(true);
    }

    private boolean isInputValid() {
        boolean valid = true;

       /* if (txtCustomerId.getText().equals("")) {
            txtCustomerId.setEditable(false);
            txtCustomerId.requestFocus();
            valid = false;
        }*/

        return valid;
    }

    private void resetForm() {

        txtBookTitle.setText("");
        txtBookShelf.setText("");
        txtBookISBN.setText("");
        txtBookAuthor.setText("");
        txtBookCategory.setText("");
        txtAvailableForLoan.setText("");
        //txtDateOfPurchase.setText("");
        /*txtPostalCode.setText("");
        txtCountry.setText("");
        txtPhone.setText("");
        txtFax.setText("");*/

    }

    public void actionPerformed(ActionEvent e) {
        if(e.getActionCommand() == btnBackToMain.getActionCommand()){
            this.toBack();
            LibrarianMenuGUI lib = new LibrarianMenuGUI();
            lib.setVisible(true);
            lib.setGui();
            dispose();
        }
        else if (e.getSource() == btnUpdate) {
            if (isInputValid()) {
                /* String customerId = txtCustomerId.getText();
            String companyName = txtCompanyName.getText();
            String contactName = txtContactName.getText();
            String contactTitle = txtContactTitle.getText();
            String address = txtAddress.getText();
            String city = txtCity.getText();
            String region = txtRegion.getText();
            String postalCode = txtPostalCode.getText();
            String country = txtCountry.getText();
            String phone = txtPhone.getText();
            String fax = txtFax.getText(); */
                AddBook b = new AddBook(txtBookTitle.getText(),
                        // txtCustomerId.getText(),
                        txtBookShelf.getText(),
                        txtBookISBN.getText(),
                        txtBookAuthor.getText(),
                        // don't forget to change status back to boolean
                        txtBookCategory.getText(),
                        txtAvailableForLoan.getText()
                        //txtDateOfPurchase.getText()
                        //txtPostalCode.getText(),
                        //txtCountry.getText(),
                        //txtPhone.getText(),
                        //txtFax.getText()
                );

                //CustomerDAO.update(c);

                //resetForm();
            }
        } else if (e.getSource() == btnReset) {
            resetForm();
            //btnUpdate.setEnabled(false);
            //btnReset.setEnabled(false);
            //btnDelete.setEnabled(false);
            
        }else if (e.getSource() == btnDelete){
                AddBook b = new AddBook(txtBookTitle.getText(),
                        // txtCustomerId.getText(),
                        txtBookShelf.getText(),
                        txtBookISBN.getText(),
                        txtBookAuthor.getText(),
                        txtBookCategory.getText(),
                        txtAvailableForLoan.getText()
                        //txtDateOfPurchase.getText()
                        //txtPostalCode.getText(),
                        //txtCountry.getText(),
                        //txtPhone.getText(),
                        //txtFax.getText()
                );
              // CustomerDAO.delete(c);

                    }

         else if (e.getActionCommand().equals("Exit")) {
            System.exit(0);
        }
    }
}
