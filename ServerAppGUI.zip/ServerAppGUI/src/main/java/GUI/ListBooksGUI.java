/*
 * ListBooksGUI.java
 * GUI class
 * @author Zandro Rohlandt (221000526)
 * 23 October 2022
 */
package GUI;

import Domain.AddBook;
import Domain.ListBooks;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;


public class ListBooksGUI extends JFrame implements ActionListener{
    private JPanel panelNorth, panelLeft, panelCenter, panelSouth;
    private JLabel lblImage, lblHeader, lblBookId, lblBookName, lblBookAuthor, lblBookPrice, lblStatus, lblEdition;
           
    private JTextField txtBookId, txtBookName, txtBookAuthor, txtBookPrice, txtStatus, txtEdition;
            
    private JTable jTable;
    private JButton btnBackToMain, btnReset, btnDelete, btnExit;

    private Font font, fontLabels;

    public ListBooksGUI() {
        super("Book");
        panelNorth = new JPanel();
        panelLeft = new JPanel();
        panelCenter = new JPanel();
        panelSouth = new JPanel();

        lblImage = new JLabel(new ImageIcon("user.png"));
        lblHeader = new JLabel("List Of All Books");

        lblBookId = new JLabel("Customer Id:            ");
        txtBookId = new JTextField();
        lblBookName = new JLabel("Company Name:            ");
        txtBookName = new JTextField();
        lblBookAuthor = new JLabel("Contact Name:            ");
        txtBookAuthor = new JTextField();
        lblBookPrice = new JLabel("Contact Title:            ");
        txtBookPrice = new JTextField();
        lblStatus = new JLabel("Address:            ");
        txtStatus = new JTextField();
        lblEdition = new JLabel("City:            ");
        txtEdition = new JTextField();
        
        jTable =new JTable();
        String[][] data = {
            { "Kundan Kumar Jha", "4031", "CSE" },
            { "Anand Jha", "6014", "IT" }
        };
        String[] columnNames = { "Name", "Roll Number", "Department" };
        // Initializing the JTable
        jTable = new JTable(data, columnNames);
        jTable.setBounds(30, 40, 200, 300);

        btnBackToMain = new JButton("Back To Main Menu");
        btnReset = new JButton("Reset");
        btnDelete = new JButton("Delete");
        btnExit = new JButton("Exit");

        font = new Font("Arial", Font.PLAIN, 26);
        fontLabels = new Font("Arial", Font.PLAIN, 22);
    }

    public void setFrame() {

        panelNorth.setLayout(new FlowLayout());
        panelLeft.setLayout(new GridLayout(7, 1));
        panelCenter.setLayout(new GridLayout(7, 1));
        panelSouth.setLayout(new GridLayout(1, 4));

        panelNorth.add(lblImage);
        panelNorth.add(lblHeader);
        lblHeader.setFont(font);
        lblHeader.setForeground(Color.yellow);
        panelNorth.setBackground(Color.BLUE);

        panelLeft.add(lblBookId);
        lblBookId.setFont(fontLabels);
        panelCenter.add(txtBookId);

        panelLeft.add(lblBookName);
        lblBookName.setFont(fontLabels);
        panelCenter.add(txtBookName);

        panelLeft.add(lblBookAuthor);
        lblBookAuthor.setFont(fontLabels);
        panelCenter.add(txtBookAuthor);

        panelLeft.add(lblBookPrice);
        lblBookPrice.setFont(fontLabels);
        panelCenter.add(txtBookPrice);

        panelLeft.add(lblStatus);
        lblStatus.setFont(fontLabels);
        panelCenter.add(txtStatus);

        panelLeft.add(lblEdition);
        lblEdition.setFont(fontLabels);
        panelCenter.add(txtEdition);


        panelCenter.add(jTable);

        btnBackToMain.setFont(font);
        btnReset.setFont(font);
        btnDelete.setFont(font);
        btnExit.setFont(font);

        panelSouth.add(btnBackToMain);
        panelSouth.add(btnReset);
        panelSouth.add(btnDelete);
        panelSouth.add(btnExit);

        this.add(panelNorth, BorderLayout.NORTH);
        this.add(panelLeft, BorderLayout.WEST);
        this.add(panelCenter, BorderLayout.CENTER);
        this.add(panelSouth, BorderLayout.SOUTH);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        btnBackToMain.addActionListener((ActionListener) this);
        btnReset.addActionListener((ActionListener) this);
        btnDelete.addActionListener((ActionListener) this);
        btnExit.addActionListener((ActionListener) this);

        this.setSize(600, 400);
        //this.setJMenuBar(menuBar);
        this.pack();
        this.setVisible(true);
    }

    private boolean isInputValid() {
        boolean valid = true;

       

        return valid;
    }

    private void resetForm() {

        txtBookId.setText("");
        txtBookName.setText("");
        txtBookAuthor.setText("");
        txtBookPrice.setText("");
        txtStatus.setText("");
        txtEdition.setText("");
        

    }

    public void actionPerformed(ActionEvent e) {
        if(e.getActionCommand() == btnBackToMain.getActionCommand()){
            this.toBack();
            LibrarianMenuGUI librarianactivities = new LibrarianMenuGUI();
            librarianactivities.setVisible(true);
            librarianactivities.setGui();
            dispose();
        } else if (e.getSource() == btnReset) {
            resetForm();
            //btnUpdate.setEnabled(false);
            //btnReset.setEnabled(false);
            //btnDelete.setEnabled(false);
            
        }else if (e.getSource() == btnDelete){
                ListBooks createloan = new ListBooks(txtBookId.getText(),
                        
                        txtBookName.getText(),
                        txtBookAuthor.getText(),
                        txtBookPrice.getText(),
                        txtStatus.getText(),
                        txtEdition.getText()
                        
                );
              

                    }

         else if (e.getActionCommand().equals("Exit")) {
            System.exit(0);
        }
    }
}
