/*
 * ListBooksByAuthorGUI.java
 * GUI class
 * @author Zandro Rohlandt (221000526)
 * 23 October 2022
 */
package GUI;

import Domain.ListBooksByAuthor;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;


public class ListBooksByAuthorGUI extends JFrame implements ActionListener{
    private JPanel panelNorth, panelCenter, panelSouth;
    private JLabel lblImage, lblHeader;
    private JTable jTable;
    private JButton btnUpdate;

    private Font font, fontLabels;

    public ListBooksByAuthorGUI() {
        super("Book");
        panelNorth = new JPanel();
       // panelLeft = new JPanel();
        panelCenter = new JPanel();
        panelSouth = new JPanel();

        lblImage = new JLabel(new ImageIcon("user.png"));
        lblHeader = new JLabel("Book Information");

       
        jTable =new JTable();
        String[][] data = {
            { "Kundan Kumar Jha", "4031", "CSE" },
            { "Anand Jha", "6014", "IT" }
        };
        String[] columnNames = { "Name", "Roll Number", "Department" };
        // Initializing the JTable
        jTable = new JTable(data, columnNames);
        jTable.setBounds(30, 40, 200, 300);

        btnUpdate = new JButton("Update");

        font = new Font("Arial", Font.PLAIN, 26);
        fontLabels = new Font("Arial", Font.PLAIN, 22);
    }

    public void setFrame() {

        panelNorth.setLayout(new FlowLayout());
        //panelLeft.setLayout(new GridLayout(2, 1));
        panelCenter.setLayout(new GridLayout(3, 1));
        panelSouth.setLayout(new GridLayout(1, 1));

        panelNorth.add(lblImage);
        panelNorth.add(lblHeader);
        lblHeader.setFont(font);
        lblHeader.setForeground(Color.yellow);
        panelNorth.setBackground(Color.BLUE);

        
        panelCenter.add(jTable);

        btnUpdate.setFont(font);

        panelSouth.add(btnUpdate);

        this.add(panelNorth, BorderLayout.NORTH);
//        this.add(panelLeft, BorderLayout.WEST);
        this.add(panelCenter, BorderLayout.CENTER);
        this.add(panelSouth, BorderLayout.SOUTH);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        btnUpdate.addActionListener((ActionListener) this);

        this.setSize(600, 400);
        this.pack();
        this.setVisible(true);
    }

    private boolean isInputValid() {
        boolean valid = true;

        return valid;
    }

    private void resetForm() {

        //txtBookId.setText("");
        //txtBookName.setText("");

    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnUpdate) {
            if (isInputValid()) {

                 ListBooksByAuthor returnBook = new ListBooksByAuthor(
                         //txtBookId.getText(),
                        //txtBookName.getText()
                );
            }
        } 

    } 
}
