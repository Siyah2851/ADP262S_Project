/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;

/**
 *
 * @author Zandr
 */
public class LibrarianMenuGUI extends JFrame implements ActionListener{
    private JMenuBar menuBar;
    private JMenu learnerMenu;
    private JMenuItem loginItem, clearItem, exitItem;
    private JMenu bookMenu;
    private JMenuItem borrowBook, returnBook;
    private JMenu loanMenu;
    private JMenuItem viewLoans, createLoan, deleteLoan;
    private JButton btnAddLearner;
    private JButton btnAddNewBook;
    private JButton btnBorrowANewBook;
    private JButton btnReturn;
    private JButton btnListAllBooks;
    private JButton btnListAllBooksByAuthor;
    private JButton btnListLearnersAlphabetically;
    private JButton signOut;
    private JPanel panelCenter;
    private Font font;

    
    
    public LibrarianMenuGUI() {
        super("Library System");
            panelCenter = new JPanel();
            
            menuBar = new JMenuBar();
            
            
            bookMenu = new JMenu("Book");
            borrowBook = new JMenuItem("Borrow Book");
            returnBook = new JMenuItem("Return Book");
            
            bookMenu.add(borrowBook);
            bookMenu.add(returnBook);
            
            menuBar.add(bookMenu);
            
            learnerMenu = new JMenu("Learner");

            loginItem = new JMenuItem("Book");
            clearItem = new JMenuItem("Learner");
            exitItem = new JMenuItem("Loan");

            learnerMenu.add(loginItem);
            learnerMenu.add(clearItem);
            learnerMenu.add(exitItem);

            menuBar.add(learnerMenu);
            
            loanMenu = new JMenu("Loan");
            viewLoans = new JMenuItem("View Loans");
            createLoan = new JMenuItem("Create Loans");
            deleteLoan = new JMenuItem("Delete Loans");
            
            loanMenu.add(viewLoans);
            loanMenu.add(createLoan);
            loanMenu.add(deleteLoan);
            
            menuBar.add(loanMenu);


            
            
            btnAddLearner = new JButton("Add New Learner");
            btnAddNewBook = new JButton("Add New Book");
            btnBorrowANewBook = new JButton("Borrow A New Book");
            btnReturn = new JButton("Return Book");
            btnListAllBooks = new JButton("List All Books");
            btnListAllBooksByAuthor = new JButton("List All Books By Author");
            btnListLearnersAlphabetically = new JButton("List All Learners Alphabetically");
            signOut = new JButton("Sign Out");
            font = new Font("Arial", Font.PLAIN, 18);
    }
        public void setGui() {
            panelCenter.setLayout(new GridLayout(8, 1));
            
            panelCenter.add(btnAddLearner);
            btnAddLearner.setFont(font);
            panelCenter.add(btnAddNewBook);
            btnAddNewBook.setFont(font);
            panelCenter.add(btnBorrowANewBook);
            btnBorrowANewBook.setFont(font);
            panelCenter.add(btnReturn);
            btnReturn.setFont(font);
            panelCenter.add(btnListAllBooks);
            btnListAllBooks.setFont(font);
            panelCenter.add(btnListAllBooksByAuthor);
            btnListAllBooksByAuthor.setFont(font);
            panelCenter.add(btnListLearnersAlphabetically);
            btnListLearnersAlphabetically.setFont(font);
            panelCenter.add(signOut);
            signOut.setFont(font);
            signOut.setBackground(Color.BLUE);

            
            this.add(panelCenter, BorderLayout.CENTER);
            this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            btnAddLearner.addActionListener((ActionListener) this);
            btnAddNewBook.addActionListener((ActionListener) this);
            btnBorrowANewBook.addActionListener((ActionListener) this);
            btnReturn.addActionListener((ActionListener) this);
            btnListAllBooks.addActionListener((ActionListener) this);
            btnListAllBooksByAuthor.addActionListener((ActionListener) this);
            btnListLearnersAlphabetically.addActionListener((ActionListener) this);
            signOut.addActionListener((ActionListener) this);
            
            this.setJMenuBar(menuBar);
            this.setSize(1000, 400);
  //        this.setJMenuBar(menuBar);
            this.pack();
            this.setVisible(true);
        }
        public void actionPerformed(ActionEvent ea) {
            
        if (ea.getActionCommand().equals(btnAddLearner.getActionCommand())) {
            //btnAddLearner.addActionListener(this);
            AddLearnerGUI learner = new AddLearnerGUI();
            learner.setVisible(true);
            learner.setFrame();
            dispose();
        }
        else if(ea.getActionCommand().equals(btnAddNewBook.getActionCommand())){
            AddBookGUI book = new AddBookGUI();
            book.setVisible(true);
            book.setFrame();
            dispose();            
        }
        else if(ea.getActionCommand().equals(btnBorrowANewBook.getActionCommand())){
            BorrowBookGUI borrowNewBook = new BorrowBookGUI();
            borrowNewBook.setVisible(true);
            borrowNewBook.setFrame();
            dispose();
        }
        else if(ea.getActionCommand().equals(btnReturn.getActionCommand())){
            BookReturnGUI loan = new BookReturnGUI();
            loan.setVisible(true);
            loan.setFrame();
            dispose();
        }
        else if(ea.getActionCommand().equals(btnListAllBooks.getActionCommand())){
            ListBooksGUI createloan = new ListBooksGUI();
            createloan.setVisible(true);
            createloan.setFrame();
            dispose();
        }
        else if(ea.getActionCommand().equals(btnListAllBooksByAuthor.getActionCommand())){
            ListBooksByAuthorGUI returnBook = new ListBooksByAuthorGUI();
            returnBook.setVisible(true);
            returnBook.setFrame();
            dispose();
        }
        else if(ea.getActionCommand().equals(btnListLearnersAlphabetically.getActionCommand())){
            ListLearnersGUI listlearnersalphabeticallygui = new ListLearnersGUI();
            listlearnersalphabeticallygui.setVisible(true);
            listlearnersalphabeticallygui.setFrame();
            dispose();
        }
        else{
            this.toBack();
            LibrarianGUI librariangui = new LibrarianGUI();
            librariangui.setVisible(true);
            librariangui.setFrame();
            dispose();        }

    }

}
