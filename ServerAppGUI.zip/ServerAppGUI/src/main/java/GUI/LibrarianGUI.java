/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/**
 *
 * @author Zandr
 */
public class LibrarianGUI extends JFrame implements ActionListener{
   
    

    private JPanel panelLeft, panelCenter, panelSouth;
    private JLabel lblUserName, lblPassword;
    private JTextField txtUserName;
    private JPasswordField txtPassword;
    private JLabel lblUserType;
    private JComboBox cboProgramme;
    private JButton btnLogin, btnExit;
    private Font font;

    public LibrarianGUI() {
        super("Library System");
        panelLeft = new JPanel();
        panelCenter = new JPanel();
        panelSouth = new JPanel();

        lblUserName = new JLabel("Username: ");
        txtUserName = new JTextField(11);
        lblPassword = new JLabel("Password: ");
        txtPassword = new JPasswordField(11);
        lblUserType = new JLabel("User Type: ");
        cboProgramme = new JComboBox();
        cboProgramme.addItem("");
        cboProgramme.addItem("Librarian");
        cboProgramme.addItem("Learner");
        

        btnLogin = new JButton("Login");
        //btnClear = new JButton("Clear");
        btnExit = new JButton("Exit");

        font = new Font("Arial", Font.PLAIN, 18);
    }

    public void setFrame() {

        panelLeft.setLayout(new GridLayout(3, 1));
        panelCenter.setLayout(new GridLayout(3, 1));
        panelSouth.setLayout(new GridLayout(1, 2));

      //  menuBar = new JMenuBar();
        //menu = new JMenu("Library Menu Bar");

        //loginItem = new JMenuItem("Book");
        //clearItem = new JMenuItem("Learner");
        //exitItem = new JMenuItem("Loan");

        //menu.add(loginItem);
        //menu.add(clearItem);
        //menu.add(exitItem);

        //menuBar.add(menu);

        lblUserName.setFont(font);
        lblUserName.setHorizontalAlignment(JLabel.LEFT);
        txtUserName.setFont(font);
        panelLeft.add(lblUserName);
        panelCenter.add(txtUserName);

        lblPassword.setFont(font);
        lblPassword.setHorizontalAlignment(JLabel.LEFT);
        txtPassword.setFont(font);
        panelLeft.add(lblPassword);
        panelCenter.add(txtPassword);
        
        lblUserType.setFont(font);
        lblUserType.setHorizontalAlignment(JLabel.LEFT);
        panelLeft.add(lblUserType);
        panelCenter.add(cboProgramme);

        btnLogin.setFont(font);
        btnLogin.setBackground(Color.BLUE);
//        btnClear.setFont(font);
//        btnClear.setBackground(Color.BLUE);

        btnExit.setFont(font);
        btnExit.setBackground(Color.BLUE);

        panelSouth.add(btnLogin);
//        panelSouth.add(btnClear);
        panelSouth.add(btnExit);

        this.add(panelLeft, BorderLayout.WEST);
        this.add(panelCenter, BorderLayout.CENTER);
        this.add(panelSouth, BorderLayout.SOUTH);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        btnLogin.addActionListener((ActionListener) this);
//        btnClear.addActionListener((ActionListener) this);
        btnExit.addActionListener((ActionListener) this);

        this.setSize(1000, 400);
        //this.setJMenuBar(menuBar);
        this.pack();
        this.setVisible(true);
    }

    private boolean isInputValid() {
        boolean valid = true;

        if (txtUserName.getText().equals("Administrator")) {
            txtUserName.requestFocus();
            valid = false;
        } else {
        }
                if (txtPassword.getText().equals("0000")) {
            txtPassword.requestFocus();
            valid = false;
        } else {
        }
                
                if (txtUserName.getText().equals("User")) {
            txtUserName.requestFocus();
            valid = false;
        } else {
        }
                if (txtPassword.getText().equals("1234")) {
            txtPassword.requestFocus();
            valid = false;
        } else {
        }

        return valid;
    }
    private void resetForm() {

        txtUserName.setText("");
        txtPassword.setText("");

    }
    
    public void actionPerformed(ActionEvent e) {
        String  username = txtUserName.getText();
        String password = txtPassword.getText();
        
        if(username.equals("librarian") && password.equals("libpassword")){
            JOptionPane.showMessageDialog(null, "Logged in successfully!");
            LibrarianMenuGUI activities = new LibrarianMenuGUI();
            activities.setVisible(true);
            activities.setGui();
            dispose();
      
        }
        else 
        {
            JOptionPane.showMessageDialog(null, "Invalid Username or Password!");
            resetForm();
        }
        
        if (e.getActionCommand().equals("Exit")) {
            System.exit(0);
        }
    }

    public static void main(String[] args) {
         //ArrayList<Librarian> prac = new ArrayList<Librarian>();
        //prac.add(new Prac("Administrator", "0000"));
        //prac.add(new Prac("User", "1234"));
        new LibrarianGUI().setFrame();
        //new LibrarianActivities().setGui();

    }

    void setGui() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
  
}
