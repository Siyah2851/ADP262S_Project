/*
 * LearnerGUI.java
 * GUI class
 * @author Zandro Rohlandt (221000526)
 * 23 October 2022
 */
package GUI;

import Domain.Learner;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author Zandr
 */
public class LearnerGUI extends JFrame implements ActionListener{
    private JPanel panelNorth, panelLeft, panelCenter, panelSouth;
    private JLabel lblImage, lblHeader, lblLearnerId, lblDateOfMembership, lblNoOfBookIssued, lblName, lblAddress, lblPhoneNo;
           // lblRegion, lblPostalCode, lblCountry, lblPhone, lblFax;
    private JTextField txtLearnerId, txtDateOfMembership, txtNoOfBookIssued, txtName, txtAddress, txtPhoneNo;
            //txtRegion, txtPostalCode, txtCountry, txtPhone, txtFax;
    private JButton btnUpdate, btnReset, btnDelete, btnExit;

    private Font font, fontLabels;

    public LearnerGUI() {
        super("Customer");
        panelNorth = new JPanel();
        panelLeft = new JPanel();
        panelCenter = new JPanel();
        panelSouth = new JPanel();

        lblImage = new JLabel(new ImageIcon("user.png"));
        lblHeader = new JLabel("Customer Information");

        lblLearnerId = new JLabel("Customer Id:            ");
        txtLearnerId = new JTextField();
        lblDateOfMembership = new JLabel("Company Name:            ");
        txtDateOfMembership = new JTextField();
        lblNoOfBookIssued = new JLabel("Contact Name:            ");
        txtNoOfBookIssued = new JTextField();
        lblName = new JLabel("Contact Title:            ");
        txtName = new JTextField();
        lblAddress = new JLabel("Address:            ");
        txtAddress = new JTextField();
        lblPhoneNo = new JLabel("City:            ");
        txtPhoneNo = new JTextField();

        btnUpdate = new JButton("Update");
        btnReset = new JButton("Reset");
        btnDelete = new JButton("Delete");
        btnExit = new JButton("Exit");

        font = new Font("Arial", Font.PLAIN, 26);
        fontLabels = new Font("Arial", Font.PLAIN, 22);
    }

    public void setFrame() {

        panelNorth.setLayout(new FlowLayout());
        panelLeft.setLayout(new GridLayout(6, 1));
        panelCenter.setLayout(new GridLayout(6, 1));
        panelSouth.setLayout(new GridLayout(1, 4));

        panelNorth.add(lblImage);
        panelNorth.add(lblHeader);
        lblHeader.setFont(font);
        lblHeader.setForeground(Color.yellow);
        panelNorth.setBackground(Color.PINK);

        panelLeft.add(lblLearnerId);
        lblLearnerId.setFont(fontLabels);
        panelCenter.add(txtLearnerId);

        panelLeft.add(lblDateOfMembership);
        lblDateOfMembership.setFont(fontLabels);
        panelCenter.add(txtDateOfMembership);

        panelLeft.add(lblNoOfBookIssued);
        lblNoOfBookIssued.setFont(fontLabels);
        panelCenter.add(txtNoOfBookIssued);

        panelLeft.add(lblName);
        lblName.setFont(fontLabels);
        panelCenter.add(txtName);

        panelLeft.add(lblAddress);
        lblAddress.setFont(fontLabels);
        panelCenter.add(txtAddress);

        panelLeft.add(lblPhoneNo);
        lblPhoneNo.setFont(fontLabels);
        panelCenter.add(txtPhoneNo);

        btnUpdate.setFont(font);
        btnReset.setFont(font);
        btnDelete.setFont(font);
        btnExit.setFont(font);

        panelSouth.add(btnUpdate);
        panelSouth.add(btnReset);
        panelSouth.add(btnDelete);
        panelSouth.add(btnExit);

        this.add(panelNorth, BorderLayout.NORTH);
        this.add(panelLeft, BorderLayout.WEST);
        this.add(panelCenter, BorderLayout.CENTER);
        this.add(panelSouth, BorderLayout.SOUTH);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        btnUpdate.addActionListener((ActionListener) this);
        btnReset.addActionListener((ActionListener) this);
        btnDelete.addActionListener((ActionListener) this);
        btnExit.addActionListener((ActionListener) this);

        this.setSize(600, 400);
        //this.setJMenuBar(menuBar);
        this.pack();
        this.setVisible(true);
    }

    private boolean isInputValid() {
        boolean valid = true;


        return valid;
    }

    private void resetForm() {

        txtLearnerId.setText("");
        txtDateOfMembership.setText("");
        txtNoOfBookIssued.setText("");
        txtName.setText("");
        txtAddress.setText("");
        txtPhoneNo.setText("");
        

    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnUpdate) {
            if (isInputValid()) {
                
                Learner l = new Learner(txtLearnerId.getText(),
                        // txtCustomerId.getText(),
                        txtDateOfMembership.getText(),
                        txtNoOfBookIssued.getText(),
                        txtName.getText(),
                        txtAddress.getText(),
                        txtPhoneNo.getText()
                        
                );

                
            }
        } else if (e.getSource() == btnReset) {
            resetForm();
            //btnUpdate.setEnabled(false);
            //btnReset.setEnabled(false);
            //btnDelete.setEnabled(false);
            
        }else if (e.getSource() == btnDelete){
                Learner l = new Learner(txtLearnerId.getText(),
                        
                        txtDateOfMembership.getText(),
                        txtNoOfBookIssued.getText(),
                        txtName.getText(),
                        txtAddress.getText(),
                        txtPhoneNo.getText()
                        
                );
              

                    }

         else if (e.getActionCommand().equals("Exit")) {
            System.exit(0);
        }
    }
}
