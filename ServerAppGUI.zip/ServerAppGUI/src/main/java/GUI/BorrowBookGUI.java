/*
 * BorrowBookGUI.java
 * GUI class
 * @author Zandro Rohlandt (221000526)
 * 23 October 2022
 */
package GUI;

import Domain.AddBook;
import Domain.BorrowBook;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class BorrowBookGUI extends JFrame implements ActionListener{
    private JPanel panelNorth, panelLeft, panelCenter, panelSouth;
    private JLabel lblImage, lblHeader, lblBookTitle, lblBookISBN, lblBookAuthor, lblBookShelf, lblAvailableForLoan;
    private JTextField txtBookTitle, txtBookISBN, txtBookAuthor, txtBookShelf, txtAvailableForLoan;
    private JButton btnUpdate, btnBackToMain;

    private Font font, fontLabels;

    public BorrowBookGUI() {
        super("Book");
        panelNorth = new JPanel();
        panelLeft = new JPanel();
        panelCenter = new JPanel();
        panelSouth = new JPanel();

        lblImage = new JLabel(new ImageIcon("user.png"));
        lblHeader = new JLabel("Book Information");

        lblBookTitle = new JLabel("Customer Title: ");
        txtBookTitle = new JTextField(25);
        lblBookISBN = new JLabel("Book ISBN : ");
        txtBookISBN = new JTextField(25);
        lblBookAuthor = new JLabel("Book Author");
        txtBookAuthor = new JTextField(25);
        lblBookShelf = new JLabel("Book Shelf");
        txtBookShelf = new JTextField(25);
        lblAvailableForLoan = new JLabel("Available For Loan?");
        txtAvailableForLoan = new JTextField(25);
        
        btnBackToMain = new JButton("Back to Main Menu");
        btnUpdate = new JButton("Update");

        font = new Font("Arial", Font.PLAIN, 26);
        fontLabels = new Font("Arial", Font.PLAIN, 22);
    }

    public void setFrame() {

        panelNorth.setLayout(new FlowLayout());
        panelLeft.setLayout(new GridLayout(5, 1));
        panelCenter.setLayout(new GridLayout(5, 1));
        panelSouth.setLayout(new GridLayout(1, 2));

        panelNorth.add(lblImage);
        panelNorth.add(lblHeader);
        lblHeader.setFont(font);
        lblHeader.setForeground(Color.yellow);
        panelNorth.setBackground(Color.BLUE);

        panelLeft.add(lblBookTitle);
        lblBookTitle.setFont(fontLabels);
        panelCenter.add(txtBookTitle);

        panelLeft.add(lblBookISBN);
        lblBookISBN.setFont(fontLabels);
        panelCenter.add(txtBookISBN);
        
        panelLeft.add(lblBookAuthor);
        lblBookAuthor.setFont(fontLabels);
        panelCenter.add(txtBookAuthor);
        
        panelLeft.add(lblBookShelf);
        lblBookShelf.setFont(fontLabels);
        panelCenter.add(txtBookShelf);
        
        panelLeft.add(lblAvailableForLoan);
        lblAvailableForLoan.setFont(fontLabels);
        panelCenter.add(txtAvailableForLoan);
        
        btnBackToMain.setFont(font);       
        btnUpdate.setFont(font);
        
        panelSouth.add(btnBackToMain);
        panelSouth.add(btnUpdate);

        this.add(panelNorth, BorderLayout.NORTH);
        this.add(panelLeft, BorderLayout.WEST);
        this.add(panelCenter, BorderLayout.CENTER);
        this.add(panelSouth, BorderLayout.SOUTH);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        btnBackToMain.addActionListener((ActionListener) this);
        btnUpdate.addActionListener((ActionListener) this);

        this.setSize(600, 400);
        this.pack();
        this.setVisible(true);
    }

    private boolean isInputValid() {
        boolean valid = true;

        return valid;
    }

    private void resetForm() {

        txtBookTitle.setText("");
        txtBookISBN.setText("");

    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnUpdate) {
            if (isInputValid()) {

                 BorrowBook issuebook = new BorrowBook(lblBookTitle.getText(),
                        txtBookISBN.getText(),
                        txtBookAuthor.getText(),
                        txtBookShelf.getText(),
                        txtAvailableForLoan.getText()
                );
            }
        } 
        else if(e.getActionCommand() == btnBackToMain.getActionCommand()){
            this.toBack();
            LibrarianMenuGUI lib = new LibrarianMenuGUI();
            lib.setVisible(true);
            lib.setGui();
            dispose();
        }

    } 
}
