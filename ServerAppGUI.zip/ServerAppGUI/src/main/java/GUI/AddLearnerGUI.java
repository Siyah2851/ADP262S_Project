/*
 * AddLearnerGUI.java
 * GUI class
 * @author Zandro Rohlandt (221000526)
 * 23 October 2022
 */
package GUI;

import Domain.AddLearner;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;


public class AddLearnerGUI extends JFrame implements ActionListener{
    private JPanel panelNorth, panelLeft, panelCenter, panelSouth;
    private JLabel lblImage, lblHeader, lblStudentNumber, lblLearnerName, lblAddress, lblPhoneNo, lblCanBorrow;
    private JTextField txtStudentNumber, txtLearnerName, txtAddress, txtPhoneNo, txtCanBorrow;
    private JButton btnBackToMain, btnReset, btnDelete, btnExit;

    private Font font, fontLabels;

    public AddLearnerGUI() {
        super("Learner");
        panelNorth = new JPanel();
        panelLeft = new JPanel();
        panelCenter = new JPanel();
        panelSouth = new JPanel();

        lblImage = new JLabel(new ImageIcon("user.png"));
        lblHeader = new JLabel("Add New Learner information");

        lblStudentNumber = new JLabel("Student Number:            ");
        txtStudentNumber = new JTextField();
        lblLearnerName = new JLabel("Learner Name:            ");
        txtLearnerName = new JTextField();
        lblAddress = new JLabel("Full Address:            ");
        txtAddress = new JTextField();
        lblPhoneNo = new JLabel("Phone Number:            ");
        txtPhoneNo = new JTextField();
        lblCanBorrow = new JLabel("Can borrow?:            ");
        txtCanBorrow = new JTextField();

        btnBackToMain = new JButton("Back To Main Menu");
        btnReset = new JButton("Reset");
        btnDelete = new JButton("Delete");
        btnExit = new JButton("Exit");

        font = new Font("Arial", Font.PLAIN, 26);
        fontLabels = new Font("Arial", Font.PLAIN, 22);
    }

    public void setFrame() {

        panelNorth.setLayout(new FlowLayout());
        panelLeft.setLayout(new GridLayout(6, 1));
        panelCenter.setLayout(new GridLayout(6, 1));
        panelSouth.setLayout(new GridLayout(1, 4));

        panelNorth.add(lblImage);
        panelNorth.add(lblHeader);
        lblHeader.setFont(font);
        lblHeader.setForeground(Color.yellow);
        panelNorth.setBackground(Color.PINK);

        panelLeft.add(lblStudentNumber);
        lblStudentNumber.setFont(fontLabels);
        panelCenter.add(txtStudentNumber);

        panelLeft.add(lblLearnerName);
        lblLearnerName.setFont(fontLabels);
        panelCenter.add(txtLearnerName);

        panelLeft.add(lblAddress);
        lblAddress.setFont(fontLabels);
        panelCenter.add(txtAddress);

        panelLeft.add(lblPhoneNo);
        lblPhoneNo.setFont(fontLabels);
        panelCenter.add(txtPhoneNo);

        panelLeft.add(lblCanBorrow);
        lblCanBorrow.setFont(fontLabels);
        panelCenter.add(txtCanBorrow);

        btnBackToMain.setFont(font);
        btnReset.setFont(font);
        btnDelete.setFont(font);
        btnExit.setFont(font);

        panelSouth.add(btnBackToMain);
        panelSouth.add(btnReset);
        panelSouth.add(btnDelete);
        panelSouth.add(btnExit);

        this.add(panelNorth, BorderLayout.NORTH);
        this.add(panelLeft, BorderLayout.WEST);
        this.add(panelCenter, BorderLayout.CENTER);
        this.add(panelSouth, BorderLayout.SOUTH);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        btnBackToMain.addActionListener((ActionListener) this);
        btnReset.addActionListener((ActionListener) this);
        btnDelete.addActionListener((ActionListener) this);
        btnExit.addActionListener((ActionListener) this);

        this.setSize(600, 400);
        //this.setJMenuBar(menuBar);
        this.pack();
        this.setVisible(true);
    }

    private boolean isInputValid() {
        boolean valid = true;

        return valid;
    }

    private void resetForm() {

        txtStudentNumber.setText("");
        txtLearnerName.setText("");
        txtAddress.setText("");
        txtPhoneNo.setText("");
        txtCanBorrow.setText("");

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnBackToMain) {
            this.toBack();
            LibrarianMenuGUI librariangui = new LibrarianMenuGUI();
            librariangui.setVisible(true);
            librariangui.setGui();
            dispose();
            }
        else if (e.getSource() == btnReset) {
            resetForm();
            //btnUpdate.setEnabled(false);
            //btnReset.setEnabled(false);
            //btnDelete.setEnabled(false);
            
        }else if (e.getSource() == btnDelete){
                AddLearner l = new AddLearner(txtStudentNumber.getText(),
                        
                        txtLearnerName.getText(),
                        txtAddress.getText(),
                        txtPhoneNo.getText(),
                        txtCanBorrow.getText()
                        
                );

                    }

         else if (e.getActionCommand().equals("Exit")) {
            System.exit(0);
        }
    }
}
