/*
 * BookReturnGUI.java
 * GUI class
 * @author Zandro Rohlandt (221000526)
 * 23 October 2022
 */
package GUI;


public class BookReturnGUI {

    void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void setFrame() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
