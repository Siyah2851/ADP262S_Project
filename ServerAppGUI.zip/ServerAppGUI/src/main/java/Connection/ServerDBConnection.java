/**
 * BookDAO.java
 * This is my ServerDB Connection class
 * Group 24 (Just Trying)
 * @author Siyakha Manisi (219239657)
 * 04 October 2022
 */
package Connection;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class ServerDBConnection {
    public static Connection derbyConnection() throws SQLException {
    String Database_url = "jdbc:derby://localhost:1527/book system";
    String username = "justtrying";
    String password = "Password123";
    Connection connection = DriverManager.getConnection(Database_url, username, password);
    return connection;
    
    }
    
    public static void main(String[] args) throws IOException  
    {
        ServerSocket ss = new ServerSocket (1234);
        Socket s = ss.accept();
        
        System.out.println("Connected to server");
        
        InputStreamReader is = new InputStreamReader (s.getInputStream());
        BufferedReader br = new BufferedReader (is);
        
        String st = br.readLine();
        System.out.println("Yes" + st);
        
        PrintWriter pw = new PrintWriter (s.getOutputStream());
        pw.println("Yes");
        pw.flush();
        
    }
    
}
