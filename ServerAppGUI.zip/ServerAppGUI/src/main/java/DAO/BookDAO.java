/**
 * BookDAO.java
 * This is my ServerDB Connection
 * Group 24 (Just Trying)
 * @author Siyakha Manisi (219239657)
 * 04 October 2022
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import Connection.ServerDBConnection;
import Domain.AddBook;
import Domain.BorrowBook;
import Domain.ListBooks;
import Domain.ListBooksByAuthor;
import Domain.BookReturn;

public class BookDAO {
    private Connection con;
    private Statement stmt;
    private PreparedStatement ps;
    
    public BookDAO() throws SQLException
    {
        this.con = ServerDBConnection.derbyConnection();
        this.stmt = this.con.createStatement();
    
    }
    
    public BorrowBook add(BorrowBook book) throws SQLException
    {
    
        String insertSQL = "INSERT INTO Book (book_title, book_shelf, book_isbn, book_author, book_category, available_for_loan) "
                + "VALUES (?, ?, ?, ?, ?, ?)";
        
        insertSQL = String.format(insertSQL, book.getBookTitle(), book.getBookShelf(), book.getBookISBN(), book.getBookAuthor(), book.getAvailableForLoan());
        System.out.println(insertSQL);
        
        this.stmt.executeUpdate(insertSQL);
        return book;  
    
    }
    
    public List<ListBooks> getAll() throws SQLException
    {
        String getAll_SQL = "SELECT * FROM Book";
        ResultSet rs = this.stmt.executeQuery(getAll_SQL);
        
        List<ListBooks> books = new ArrayList<>();
            while (rs.next())
            {
                String bookId = rs.getString("book_id");    
                String bookName = rs.getString("book_name");
                String bookAuthor = rs.getString("book_author");
                String bookPrice = rs.getString ("book_shelf");
                String bookStatus = rs.getString ("status");
                String bookEdition = rs.getString ("edition");
       
                ListBooks bk = new ListBooks (bookId, bookName, bookAuthor, 
			bookPrice, bookStatus, bookEdition);
            }
        System.out.println(getAll_SQL);
        rs.close();
        return books;
    
    }
    
    public List<ListBooksByAuthor> getAllBooks() throws SQLException
    {
        String getAll_SQL = "SELECT * FROM Book";
        ResultSet rs = this.stmt.executeQuery(getAll_SQL);
        
        List<ListBooksByAuthor> books = new ArrayList<>();
            while (rs.next())
            {
                String bookId = rs.getString("book_id");    
                String learnerId = rs.getString("learner_id");
                
                ListBooksByAuthor bk = new ListBooksByAuthor (bookId, learnerId);
            
            }
            
            System.out.println(getAll_SQL);
            rs.close();
            return books;
            
    }
    
    public List <AddBook> getTrueCanBeLoaned() throws SQLException
    {
        String getAll_SQL = "*SELECT * FROM Book WHERE is_available_for_loan = true ";
        ResultSet rs = this.stmt.executeQuery(getAll_SQL);
        
        List<AddBook> books = new ArrayList<>();
            while (rs.next())
            {
                String bookTitle = rs.getString("book_title");
                String bookShelf = rs.getString("book_shelf");
                String bookISBN = rs.getString("book_isbn");    
                String bookAuthor = rs.getString("book_author");
                String bookCategory = rs.getString("book_category");
                String bookAvailability = rs.getString ("availableForLoan");
       
                AddBook bk = new AddBook (bookTitle, bookShelf, bookISBN, bookAuthor, 
			bookCategory, bookAvailability);
            }
        System.out.println(getAll_SQL);
        rs.close();
        return books;       
        
    }
    
    public List <AddBook> getFalseCanBeLoaned() throws SQLException
    {
        String getAll_SQL = "*SELECT * FROM Book WHERE is_available_for_loan = false ";
        ResultSet rs = this.stmt.executeQuery(getAll_SQL);
        
        List<AddBook> books = new ArrayList<>();
            while (rs.next())
            {
                String bookTitle = rs.getString("book_title");
                String bookShelf = rs.getString("book_shelf");
                String bookISBN = rs.getString("book_isbn");    
                String bookAuthor = rs.getString("book_author");
                String bookCategory = rs.getString("book_category");
                String bookAvailability = rs.getString ("availableForLoan");
       
                AddBook bk = new AddBook (bookTitle, bookShelf, bookISBN, bookAuthor, 
			bookCategory, bookAvailability);
            }

        System.out.println(getAll_SQL);
        rs.close();
        return books;       
        
    }
    
    
    public void updateBook (BookReturn book) throws SQLException 
    {
        String updateQuery = "SELECT learner_id, membership_date, no_of_book_issued, name, address, contacts FROM book";
        updateQuery = String.format(updateQuery, book.getLearnerId(),book.getDateOfMembership(),book.getNoOfBookIsued(),
                                        book.getName(), book.getAddress(), book.getPhoneNo());

        System.out.println(updateQuery);
        String update_SQL = "UPDATE Book SET is_active = ? WHERE book_id = ?";

        ps = con.prepareStatement(update_SQL);
        ps.setString(1, book.getLearnerId());
        ps.setString(2, book.getDateOfMembership());
        ps.setString(3, book.getNoOfBookIsued());
        ps.setString(4, book.getName());
        ps.setString(5, book.getAddress());
        ps.setString(7, book.getPhoneNo());


        ps.executeUpdate();
        ps.close();
	  
    }
    
    /* public void deleteBook (ListBooks book) throws SQLException
        {
            String deleteSQL = "DELETE FROM book " +
            "WHERE book_id = ?";
			ResultSet rs = this.stmt.executeQuery(deleteSQL);
         
            while(rs.next())
            {
                //Display values
                System.out.print("bookId: " + rs.getString("book_id"));
                System.out.print(", bookName: " + rs.getString("book_name"));
                System.out.print(", bookAuthor: " + rs.getString("book_author"));
                System.out.println(", bookPrice: " + rs.getString("book_price"));
            }
            rs.close();
       
    }*/
    
    
    public void closeResources() throws SQLException
    {
        this.con.close();
        this.stmt.close();
    }
    

}
