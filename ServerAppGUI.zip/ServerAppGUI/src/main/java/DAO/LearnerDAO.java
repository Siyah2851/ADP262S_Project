/**
 * LearnerDAO.java
 * This is my Learner DB connection class
 * Group 24 (Just Trying)
 * @author Siyakha Manisi (219239657)
 * 04 October 2022
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import Connection.ServerDBConnection;
import Domain.AddLearner;
import Domain.Learner;
import Domain.ListLearners;



public class LearnerDAO {
    private Connection con;
    private Statement statement;
    private PreparedStatement ps;
    
    public LearnerDAO() throws SQLException
    {
        this.con = ServerDBConnection.derbyConnection();
        this.statement = this.con.createStatement();
                
    }
   
    
    public AddLearner add(AddLearner lnr) throws SQLException
    {
    
        String insertSQL = "INSERT INTO Learner (student_number, learner_name, address, contacts, canBorrow) "
                + "VALUES (?, ?, ?, ?, ?)";
        
        insertSQL = String.format(insertSQL, lnr.getStudentNumber(), lnr.getLearnerName(), lnr.getAddress(), lnr.getPhoneNo(), 
                            lnr.getCanBorrow());
        System.out.println(insertSQL);
        
        this.statement.executeUpdate(insertSQL);
        return lnr;  
    
    }
    
       public List<ListLearners> getAll() throws SQLException
       {
            String getAll_SQL = "SELECT * FROM Learner";
            ResultSet rs = this.statement.executeQuery(getAll_SQL);
        
            List<ListLearners> lnrs = new ArrayList<>();
            while (rs.next())
            {
                String learnerId = rs.getString("learner_id");    
                String membershipDate = rs.getString("membership_date");
                String noOfBookIssued = rs.getString("no_of_bookIssued");
                String name = rs.getString("name");
                String address = rs.getString("address");
                String contacts = rs.getString("contacts");
       
                ListLearners lnr = new ListLearners(learnerId, membershipDate, noOfBookIssued, 
				name, address, contacts);
            }
        System.out.println(getAll_SQL);
        rs.close();
        return lnrs;
    }
       
    public void updateLearner (Learner lnr) throws SQLException 
    {
        String updateQuery = "SELECT learner_id, FROM learner";
        updateQuery = String.format(updateQuery, lnr.getLearnerId(), lnr.getName());
    
        System.out.println(updateQuery);
        String update_SQL = "UPDATE Learner SET is_active = ? WHERE learner_id = ?";
    
        ps = con.prepareStatement(update_SQL);
        ps.setString(1, lnr.getLearnerId());
        // ps.setString(2, lnr.getDateOfMembership());
        //ps.setString(3, lnr.getnoOfBookIsued());
        ps.setString(4, lnr.getName());
        //ps.setString(5, lnr.getAddress());
        //ps.setString(6, lnr.getPhoneNo());
    
    
        ps.executeUpdate();
        ps.close();
	  
    }
   
    
  /* public void deleteLearner (Learner lnr) throws SQLException
    {
        String deleteSQL = "DELETE FROM learner " +
            "WHERE learner_id = ?";
                ResultSet rs = this.statement.executeQuery(deleteSQL);
         
         while(rs.next()){
            //Display values
            System.out.print("learnerId: " + rs.getString("learner_id"));
            System.out.print(", name: " + rs.getString("name"));
            System.out.print(", address: " + rs.getString("address"));
            
         }
         rs.close();
       
    }*/
    
    public void closeResources() throws SQLException
    {
        this.con.close();
        this.statement.close();
    }
    
}
