/**
 * LoginDAO.java
 * This is my Librarian login DB connection class
 * Group 24 (Just Trying)
 * @author Siyakha Manisi (219239657)
 * 04 October 2022
 */
package DAO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import Connection.ServerDBConnection;
import Domain.Librarian;


public class LoginDAO {
    private Connection con;
    private Statement statement;

 
    public LoginDAO() throws SQLException
    {
        this.con = ServerDBConnection.derbyConnection();
        this.statement = this.con.createStatement();

    }

//CREATE
    public Librarian create (Librarian login) throws SQLException
    {
        String insertSQL = "INSERT INTO Librarian (user_name, password) " +
                   "VALUES (?, ?)" ;

        insertSQL = String.format(insertSQL, login.getUserName(),
                login.getPassword());
        System.out.println(insertSQL);
        
        this.statement.executeUpdate(insertSQL);
        return login;

    }

//Read
public List<Librarian> getAll() throws SQLException
    {
        String getAll_SQL = "SELECT * FROM Librarian";
        ResultSet rs = this.statement.executeQuery(getAll_SQL);
        
        List<Librarian> loginDetails = new ArrayList<>();
            while (rs.next())
            {
                String userName = rs.getString("user_name");    
                String password = rs.getString("password");
           
       
                Librarian login = new Librarian(userName, password);
                loginDetails.add(login);
            
            }
            
            System.out.println(getAll_SQL);
            rs.close();
            return loginDetails;
			
    }

//Update
public void updateLibrarian (Librarian login) throws SQLException 
    {
        String updateQuery = "SELECT user_name, password FROM Librarian";
        updateQuery = String.format(updateQuery, login.getUserName(), login.getPassword());
        System.out.println(updateQuery);
        String update_SQL = "UPDATE Librarian " + "WHERE user_name = username, password = password";

		statement.executeUpdate(update_SQL);
        ResultSet rs = this.statement.executeQuery(updateQuery);
        
            while (rs.next())
            {
                System.out.print("userName: " + rs.getInt("user_name"));
                System.out.print(", password: " + rs.getDouble("password"));
            }
            System.out.println(update_SQL);
            rs.close(); 
    }

//Delete
    public void deleteLibrarian(Librarian login) throws SQLException 
    {
        // static final String Database_url = "jdbc:derby://localhost:1527/booksystem";
        // static final String username = "justtrying";
        //static final String password = "Password123"; 
        String Query = "SELECT user_name, password ";
        Query = String.format(Query, login.getUserName(), login.getPassword());
        System.out.println(Query);
   
        {		      
            String DELETE_SQL = "DELETE FROM librarian " +
				"WHERE user_name = ?";
            statement.executeUpdate(DELETE_SQL);
            ResultSet rs = statement.executeQuery(Query);
            while(rs.next())
            {
                //Display values
                System.out.print("userName: " + rs.getString("user_name"));
                System.out.print(", password " + rs.getString("password"));
            }
            rs.close();
       
        } 
       
    }
    
    public void closeResources() throws SQLException
    {
        this.con.close();
        this.statement.close();
    
    }
    
}
