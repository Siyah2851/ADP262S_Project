/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Domain;

/**
 *
 * @author Zandr
 */
public class AddBook {
    private String bookTitle;
    private String bookShelf;
    private String bookISBN;
    private String bookAuthor;
    private String bookCategory;
    private String availableForLoan;

    public AddBook() {
    }

    public AddBook(String bookTitle, String bookShelf, String bookISBN, String bookAuthor, String bookCategory, String availableForLoan) {
        this.bookTitle = bookTitle;
        this.bookShelf = bookShelf;
        this.bookISBN = bookISBN;
        this.bookAuthor = bookAuthor;
        this.bookCategory = bookCategory;
        this.availableForLoan = availableForLoan;
    }

    public void setBookTitle(String bookTitle) {
        this.bookTitle = bookTitle;
    }

    public void setBookShelf(String bookShelf) {
        this.bookShelf = bookShelf;
    }

    public void setBookISBN(String bookISBN) {
        this.bookISBN = bookISBN;
    }

    public void setBookAuthor(String bookAuthor) {
        this.bookAuthor = bookAuthor;
    }

    public void setBookCategory(String bookCategory) {
        this.bookCategory = bookCategory;
    }

    public void setAvailableForLoan(String availableForLoan) {
        this.availableForLoan = availableForLoan;
    }

    @Override
    public String toString() {
        return "Book{" + "bookTitle=" + bookTitle + ", bookShelf=" + bookShelf + ", bookISBN=" + bookISBN + ", bookAuthor=" + bookAuthor + ", bookCategory=" + bookCategory + ", availableForLoan=" + availableForLoan + '}';
    }   
    
}
