/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Domain;

/**
 *
 * @author Zandr
 */
public class AddLearner {
    private String studentNumber;
    private String learnerName;
    private String address;
    private String phoneNo;
    private String canBorrow;

    public AddLearner() {
    }

    public AddLearner(String studentNumber, String learnerName, String address, String phoneNo, String canBorrow) {
        this.studentNumber = studentNumber;
        this.learnerName = learnerName;
        this.address = address;
        this.phoneNo = phoneNo;
        this.canBorrow = canBorrow;
    }

    public void setStudentNumber(String studentNumber) {
        this.studentNumber = studentNumber;
    }

    public void setLearnerName(String learnerName) {
        this.learnerName = learnerName;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public void setCanBorrow(String canBorrow) {
        this.canBorrow = canBorrow;
    }

    public String getStudentNumber() {
        return studentNumber;
    }

    public String getLearnerName() {
        return learnerName;
    }

    public String getAddress() {
        return address;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public String getCanBorrow() {
        return canBorrow;
    }

    @Override
    public String toString() {
        return "Learner{" + "studentNumber=" + studentNumber + ", learnerName=" + learnerName + ", address=" + address + ", phoneNo=" + phoneNo + ", canBorrow=" + canBorrow + '}';
    }

    
}
