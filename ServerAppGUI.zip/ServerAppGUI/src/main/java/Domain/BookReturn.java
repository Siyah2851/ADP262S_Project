/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Domain;

/**
 *
 * @author Zandr
 */
public class BookReturn {
     private String learnerId;
    private String dateOfMembership;
    private String noOfBookIsued;
    private String name;
    private String address;
    private String phoneNo;

    public BookReturn() {
    }

    public BookReturn(String learnerId, String dateOfMembership, String noOfBookIsued, String name, String address, String phoneNo) {
        this.learnerId = learnerId;
        this.dateOfMembership = dateOfMembership;
        this.noOfBookIsued = noOfBookIsued;
        this.name = name;
        this.address = address;
        this.phoneNo = phoneNo;
    }

    public void setLearnerId(String learnerId) {
        this.learnerId = learnerId;
    }

    public void setDateOfMembership(String dateOfMembership) {
        this.dateOfMembership = dateOfMembership;
    }

    public void setNoOfBookIsued(String noOfBookIsued) {
        this.noOfBookIsued = noOfBookIsued;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public String getLearnerId() {
        return learnerId;
    }

    public String getDateOfMembership() {
        return dateOfMembership;
    }

    public String getNoOfBookIsued() {
        return noOfBookIsued;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    @Override
    public String toString() {
        return "Learner{" + "learnerId=" + learnerId + ", dateOfMembership=" + dateOfMembership + ", noOfBookIsued=" + noOfBookIsued + ", name=" + name + ", address=" + address + ", phoneNo=" + phoneNo + '}';
    }
       
}
