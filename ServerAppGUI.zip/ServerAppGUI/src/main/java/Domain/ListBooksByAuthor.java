/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Domain;

/**
 *
 * @author Zandr
 */
public class ListBooksByAuthor {
     private String bookId;
    private String learnerId;

    public ListBooksByAuthor() {
    }

    public ListBooksByAuthor(String bookId, String learnerId) {
        this.bookId = bookId;
        this.learnerId = learnerId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public void setLearnerId(String learnerId) {
        this.learnerId = learnerId;
    }

    public String getBookId() {
        return bookId;
    }

    public String getLearnerId() {
        return learnerId;
    }

    @Override
    public String toString() {
        return "IssueBook{" + "bookId=" + bookId + ", learnerId=" + learnerId + '}';
    }
}
