/**
 * LostBooksByAuthor.java
 * POJO class for listing the books by author
 * @author Zandro Rohlandt (221000526)
 * 23 October 2022
 */
package Domain;


public class ListBooksByAuthor {
     private String bookId;
    private String learnerId;

    public ListBooksByAuthor() {
    }

    public ListBooksByAuthor(String bookId, String learnerId) {
        this.bookId = bookId;
        this.learnerId = learnerId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public void setLearnerId(String learnerId) {
        this.learnerId = learnerId;
    }

    public String getBookId() {
        return bookId;
    }

    public String getLearnerId() {
        return learnerId;
    }

    @Override
    public String toString() {
        return "IssueBook{" + "bookId=" + bookId + ", learnerId=" + learnerId + '}';
    }
}
