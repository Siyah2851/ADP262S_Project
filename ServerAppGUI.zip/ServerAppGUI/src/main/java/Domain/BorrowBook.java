/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Domain;

/**
 *
 * @author Zandr
 */
public class BorrowBook {
    private String bookTitle;
    private String bookISBN;
    private String bookAuthor;
    private String bookShelf;
    private String availableForLoan;

    public BorrowBook() {
    }

    public BorrowBook(String bookTitle, String bookISBN, String bookAuthor, String bookShelf, String availableForLoan) {
        this.bookTitle = bookTitle;
        this.bookISBN = bookISBN;
        this.bookAuthor = bookAuthor;
        this.bookShelf = bookShelf;
        this.availableForLoan = availableForLoan;
    }

    public void setBookTitle(String bookTitle) {
        this.bookTitle = bookTitle;
    }

    public void setBookISBN(String bookISBN) {
        this.bookISBN = bookISBN;
    }

    public void setBookAuthor(String bookAuthor) {
        this.bookAuthor = bookAuthor;
    }

    public void setBookShelf(String bookShelf) {
        this.bookShelf = bookShelf;
    }

    public void setAvailableForLoan(String availableForLoan) {
        this.availableForLoan = availableForLoan;
    }

    public String getBookTitle() {
        return bookTitle;
    }

    public String getBookISBN() {
        return bookISBN;
    }

    public String getBookAuthor() {
        return bookAuthor;
    }

    public String getBookShelf() {
        return bookShelf;
    }

    public String getAvailableForLoan() {
        return availableForLoan;
    }

    @Override
    public String toString() {
        return "IssueBook{" + "bookTitle=" + bookTitle + ", learnerBookISBN=" + bookISBN + ", bookAuthor=" + bookAuthor + ", bookShelf=" + bookShelf + ", availableForLoan=" + availableForLoan + '}';
    }   
    
}
