/**
 * ListBooks.java
 * POJO class for listing the books
 * @author Zandro Rohlandt (221000526)
 * 23 October 2022
 */
package Domain;

public class ListBooks {
        private String bookId;
    private String bookName;
    private String bookAuthor;
    private String bookPrice;
    private String status;
    private String edition;

    public ListBooks() {
    }

    public ListBooks(String bookId, String bookName, String bookAuthor, String bookPrice, String status, String edition) {
        this.bookId = bookId;
        this.bookName = bookName;
        this.bookAuthor = bookAuthor;
        this.bookPrice = bookPrice;
        this.status = status;
        this.edition = edition;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public void setBookAuthor(String bookAuthor) {
        this.bookAuthor = bookAuthor;
    }

    public void setBookPrice(String bookPrice) {
        this.bookPrice = bookPrice;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setEdition(String edition) {
        this.edition = edition;
    }

    public String getBookId() {
        return bookId;
    }

    public String getBookName() {
        return bookName;
    }

    public String getBookAuthor() {
        return bookAuthor;
    }

    public String getBookPrice() {
        return bookPrice;
    }

    public String getStatus() {
        return status;
    }

    public String getEdition() {
        return edition;
    }

    @Override
    public String toString() {
        return "Book{" + "bookId=" + bookId + ", bookName=" + bookName + ", bookAuthor=" + bookAuthor + ", bookPrice=" + bookPrice + ", status=" + status + ", edition=" + edition + '}';
    }
}
