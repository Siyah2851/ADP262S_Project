/**
 * Librarian.java
 * This is my Librarian POJO class
 * @author Siyakha Manisi (219239657)
 * 23 October 2022
 */
package Domain;


public class Librarian {
    private String userName;
    private String password;


    public Librarian() {
    }

    public Librarian(String userName, String password) {
        this.userName = userName;
        this.password = password;

    }

    public String getUserName() {
        return userName;
    }

    public String getPassword() {
        return password;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "UserW{" + "userName=" + userName + ", password=" + password + '}';
    }

 
}
